// Este código pode ser usado para adicionar funcionalidades extras futuramente
document.addEventListener('DOMContentLoaded', () => {
    console.log("Catálogo de Vídeos Estilo Aluraflix Carregado!");
});
